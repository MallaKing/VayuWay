#!/bin/bash

echo "Fetching from: http://192.168.1.8:8000"

ID=123 # Replace with a valid _id from your DB

curl -X GET "http://192.168.1.8:8000/api/v1/corridors/$ID" \
  -H "Content-Type: application/json"