#!/bin/bash
echo "Posting to: http://192.168.1.8:8000"

USER="john_doe"
ID=123
FILE="corridor.json"

jq -n --arg user "$USER" --argjson corid "$ID" --argjson corridor "$(cat $FILE)" \
  '{user: $user, corid: $corid, corridor: $corridor}' > payload.json

curl -X POST  http://192.168.1.8:8000/api/v1/corridors/new \
  -H "Content-Type: application/json" \
  -d @payload.json
